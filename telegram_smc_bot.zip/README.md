# Telegram SMC Bot (Render, Python)

Bot do Telegram que realiza **análise de criptomoedas** com:
- EMAs **9/21/80/200**
- Volume vs **média de 21 períodos**
- **Suportes/Resistências** (pivôs)
- **LTA/LTB** (últimos pivôs)
- **POC** (perfil de volume aproximado)
- **CVD** (delta cumulativo por direção de candle)
- **FVG**, **OB**, **BoS/ChoCH** (heurísticas)
- **Fibonacci** (retração/expansão)
- **Liquidações** (Bybit, via WebSocket – amostragem curta)
- **Estado dos mercados globais** (NYSE, LSE, TSE, HKEX, B3)
- Coleta de **candles** com *fallbacks gratuitos*: Bybit → Kraken → MEXC → BitMEX

> **Aviso**: As detecções de OB/BoS/ChoCH/FVG são heurísticas educacionais, não garantem precisão institucional.

## Comandos do bot
- `/start` – instruções básicas
- `/analisa <PAR> <TF>` – exemplo: `/analisa BTCUSDT 1h`

TFs aceitos: `1m,5m,15m,30m,1h,4h,1d`. (Nem todas as fontes oferecem todos os TFs; o código faz *fallback*.)

## Instalação local
1. Python 3.10+
2. `pip install -r requirements.txt`
3. Crie `.env` (baseado em `.env.example`) **ou** exporte variáveis:
   - `TELEGRAM_BOT_TOKEN`
   - `WEBHOOK_URL` (quando for usar webhook)
   - `WEBHOOK_SECRET` (string aleatória)
4. Execute:
   ```bash
   uvicorn app:app --host 0.0.0.0 --port 10000
   ```
5. Configure o **webhook** do Telegram apontando para `WEBHOOK_URL/WEBHOOK_SECRET` (Render fará isso no startup automaticamente quando `WEBHOOK_URL` estiver definido).

> Para testes locais sem URL pública, você pode usar `ngrok http 10000` e setar `WEBHOOK_URL=https://<ngrok-id>.ngrok.io/telegram`.

## Deploy no Render (plano gratuito)
1. Faça **fork** deste repositório no GitHub.
2. No Render: **New → Web Service → Connect repo**.
3. Linguagem: *Python*.  
   Build command: `pip install -r requirements.txt`  
   Start command: `uvicorn app:app --host 0.0.0.0 --port $PORT`
4. Em **Environment** crie variáveis:
   - `TELEGRAM_BOT_TOKEN=...`
   - `WEBHOOK_URL=https://<seu-servico>.onrender.com/telegram`
   - `WEBHOOK_SECRET` (Generate)
5. Deploy. Ao iniciar, o app define o webhook automaticamente.
6. Abra o bot no Telegram e envie `/analisa BTCUSDT 1h`.

### Notas Render
- Plano gratuito pode hibernar; o primeiro acesso “acorda” o serviço.
- WebSockets outbound (para liquidações Bybit) funcionam; o código limita tempo de escuta para não travar a resposta.
- Se o **PORT** for injetado pelo Render, o Uvicorn usa `$PORT` automaticamente. (Definimos default `10000`.)

## Como a análise funciona (resumo)
- Baixa até **500 candles** do TF pedido.
- Calcula **EMAs**; define *bias* (Alta/Baixa/Neutro) e propõe **Entrada/TPs/SL** usando POC e S/R mais próximos.
- **POC**: histograma de preços ponderado por volume (aproximação).
- **CVD**: soma volumes positivos/negativos conforme direção do candle.
- **FVG**: detecção de *gaps* em janelas de 3 candles recentes.
- **OB**: última vela contrária antes de movimento impulsivo.
- **BoS/ChoCH**: rompeu último pivot high/low? (simplificado).
- **Fibonacci**: níveis entre o *high/low* dos últimos 150 candles.
- **Mercados**: estado (aberto/fechado) por fuso.

## Limitações & melhorias futuras
- Melhorar mapeamentos de símbolos (Kraken/BitMEX têm convenções próprias).
- Persistir *buffer* de liquidações em *background task*.
- Adicionar gráficos/imagens das regiões (necessitaria serviço de renderização).
- Mais fontes (Binance etc.) quando possível.
- Parâmetros configuráveis por comando.

## Licença
MIT
