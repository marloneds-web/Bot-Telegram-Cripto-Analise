import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple

def ema(df: pd.DataFrame, period: int, col: str="close"):
    return df[col].ewm(span=period, adjust=False).mean()

def volume_ma(df: pd.DataFrame, period: int=21):
    return df["volume"].rolling(period).mean()

def pivots(df: pd.DataFrame, left: int=3, right: int=3):
    highs, lows = [], []
    for i in range(left, len(df)-right):
        window = df.iloc[i-left:i+right+1]
        if df["high"].iloc[i] == window["high"].max():
            highs.append((i, df["high"].iloc[i]))
        if df["low"].iloc[i] == window["low"].min():
            lows.append((i, df["low"].iloc[i]))
    return highs, lows

def support_resistance(df: pd.DataFrame, left: int=3, right: int=3, min_dist: float=0.002):
    highs, lows = pivots(df, left, right)
    levels = sorted({round(price, 6) for _, price in highs + lows})
    merged = []
    for lvl in levels:
        if not merged or abs(lvl - merged[-1])/lvl > min_dist:
            merged.append(lvl)
    close = df["close"].iloc[-1]
    supports = sorted([x for x in merged if x <= close], reverse=True)[:3]
    resistances = sorted([x for x in merged if x > close])[:3]
    return supports, resistances

def trendlines(df: pd.DataFrame):
    highs, lows = pivots(df, left=5, right=5)
    def line(p1, p2):
        (i1, y1), (i2, y2) = p1, p2
        m = (y2 - y1) / (i2 - i1)
        b = y1 - m * i1
        return m, b
    LTA, LTB = None, None
    if len(lows) >= 2:
        LTA = line(lows[-2], lows[-1])
    if len(highs) >= 2:
        LTB = line(highs[-2], highs[-1])
    def value_at(line_tuple, x):
        if line_tuple is None: return None
        m,b = line_tuple
        return m*x + b
    last_idx = len(df)-1
    return {
        "LTA": {"slope": None if LTA is None else LTA[0], "value_now": None if LTA is None else value_at(LTA, last_idx)},
        "LTB": {"slope": None if LTB is None else LTB[0], "value_now": None if LTB is None else value_at(LTB, last_idx)},
    }

def volume_profile_poc(df: pd.DataFrame, bins: int=50):
    prices = df["close"].values
    vols = df["volume"].values
    hist, edges = np.histogram(prices, bins=bins, weights=vols)
    idx = int(hist.argmax())
    poc = (edges[idx] + edges[idx+1]) / 2
    return float(poc)

def cvd(df: pd.DataFrame):
    delta = np.where(df["close"].diff().fillna(0) >= 0, df["volume"], -df["volume"])
    return pd.Series(delta).cumsum().iloc[-1]

def fvg(df: pd.DataFrame, max_bars_back: int=200):
    for i in range(len(df)-3, len(df)-max_bars_back-1, -1):
        if i < 2: break
        h1 = df["high"].iloc[i-2]
        l3 = df["low"].iloc[i]
        if l3 > h1:
            return {"type":"bullish", "gap_top": l3, "gap_bottom": h1}
        l1 = df["low"].iloc[i-2]
        h3 = df["high"].iloc[i]
        if h3 < l1:
            return {"type":"bearish", "gap_top": l1, "gap_bottom": h3}
    return None

def swings(df: pd.DataFrame, left: int=3, right: int=3):
    highs, lows = pivots(df, left, right)
    return highs, lows

def ob_zones(df: pd.DataFrame, lookback: int=200):
    rng = df["high"] - df["low"]
    avg = rng.rolling(20).mean()
    zones = []
    for i in range(len(df)-lookback, len(df)-1):
        if avg.iloc[i] == 0 or pd.isna(avg.iloc[i]): 
            continue
        if rng.iloc[i+1] > 1.5*avg.iloc[i]:
            if df["close"].iloc[i] < df["open"].iloc[i]:
                zones.append({"type":"demand","level_low": df["low"].iloc[i], "level_high": df["high"].iloc[i]})
            else:
                zones.append({"type":"supply","level_low": df["low"].iloc[i], "level_high": df["high"].iloc[i]})
    return zones[-2:] if zones else []

def bos_choch(df: pd.DataFrame, left: int=3, right: int=3):
    highs, lows = pivots(df, left, right)
    last_close = df["close"].iloc[-1]
    last_high = highs[-1][1] if highs else None
    last_low = lows[-1][1] if lows else None
    bos = None
    choch = None
    if last_high and last_close > last_high:
        bos = "Bullish BoS (higher high)"
    if last_low and last_close < last_low:
        choch = "Bearish ChoCH (lower low)"
    return bos, choch

def pack_summary(df: pd.DataFrame) -> dict:
    ema9 = ema(df, 9)
    ema21 = ema(df, 21)
    ema80 = ema(df, 80)
    ema200 = ema(df, 200)
    vol21 = volume_ma(df, 21)
    supports, resistances = support_resistance(df)
    tl = trendlines(df)
    poc = volume_profile_poc(df)
    cvd_val = cvd(df)
    fvg_last = fvg(df)
    bos, choch = bos_choch(df)
    return {
        "ema": {"9": float(ema9.iloc[-1]), "21": float(ema21.iloc[-1]), "80": float(ema80.iloc[-1]), "200": float(ema200.iloc[-1])},
        "volume_vs_ma21": {"last": float(df["volume"].iloc[-1]), "ma21": float(vol21.iloc[-1]) if not pd.isna(vol21.iloc[-1]) else None},
        "supports": supports, "resistances": resistances,
        "trendlines": tl, "poc": poc, "cvd": float(cvd_val),
        "fvg": fvg_last,
        "bos": bos, "choch": choch
    }
