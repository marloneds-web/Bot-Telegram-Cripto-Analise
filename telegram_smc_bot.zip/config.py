import os

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")
PORT = int(os.getenv("PORT", "10000"))

# Data sources order (fallbacks)
DATA_SOURCES = ["bybit", "kraken", "mexc", "bitmex"]
DEFAULT_LIMIT = 500  # candles to fetch
